using FluentValidation.TestHelper;

using AccountantsPayablePreregistration;

namespace TestProject;

public class UnitTest1
{
    [Fact]
    public void TestManyErrors()
    {
        var ds = new DocsSet(
            "5",
            new Company(string.Empty, string.Empty, string.Empty),
            "5",
            new List<TransferDocument>(),
            DateOnly.MinValue,
            DateOnly.MinValue,
            DateOnly.MinValue,
            new List<ReceiptOrder> (),
            true,
            true,
            true);

        var v = new DocsSetValidator();
        var vr = v.TestValidate(ds);

        Assert.False(vr.IsValid);
    }

    [Fact]
    public void TestCorrect()
    {
        var ds = new DocsSet(
            "5",
            new Company(string.Empty, string.Empty, string.Empty),
            "5",
            new List<TransferDocument> ()
            {
                new TransferDocument(
                    "5",
                    "5",
                    DateOnly.MaxValue,
                    new Contractor("5000050000", String.Empty),
                    5,
                    1,
                    6)
            },
            DateOnly.MaxValue,
            DateOnly.MaxValue,
            DateOnly.MaxValue,
            new List<ReceiptOrder> (),
            true,
            false,
            false);

        var v = new DocsSetValidator();
        var vr = v.Validate(ds);

        Assert.True(vr.IsValid);
    }

    [Fact]
    public void TestNullTransferDocumentNumber()
    {
        var ds = new DocsSet(
            "5",
            new Company(string.Empty, string.Empty, string.Empty),
            "5",
            new List<TransferDocument>()
            {
                new TransferDocument(
                    "5",
                    null,
                    DateOnly.MaxValue,
                    new Contractor("5000050000", String.Empty),
                    5,
                    1,
                    6)
            },
            DateOnly.MaxValue,
            DateOnly.MaxValue,
            DateOnly.MaxValue,
            new List<ReceiptOrder>(),
            true,
            false,
            false);

        var v = new DocsSetValidator();
        var vr = v.TestValidate(ds);

        //Assert.True(vr.ShouldHaveValidationErrorFor(ds => ds.TransferDocuments));
    }
}