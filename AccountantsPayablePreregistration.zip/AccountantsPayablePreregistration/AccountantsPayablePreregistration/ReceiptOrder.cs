﻿namespace AccountantsPayablePreregistration;

/// <summary>
/// Приходный ордер
/// </summary>
public class ReceiptOrder
{
    public string Number { get; }
    /// <summary>
    /// Номер заказа на поставку
    /// </summary>
    public string PurschaseOrderNumber { get; }
    public string OperationTypeCode { get; }

    public ReceiptOrder(string number, string purschaseOrderNumber, string operationTypeCode)
    {
        Number = number;
        PurschaseOrderNumber = purschaseOrderNumber;
        OperationTypeCode = operationTypeCode;
    }
}