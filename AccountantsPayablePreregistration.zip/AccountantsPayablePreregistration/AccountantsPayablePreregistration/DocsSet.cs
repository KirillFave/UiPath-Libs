﻿namespace AccountantsPayablePreregistration;

public class DocsSet
{
    public string ItemId { get; }
    public Company Company { get; }
    public string RegistrationNumber { get; }
    public Uri Uri { get; }
    /// <summary>
    /// Передаточный документ
    /// </summary>
    public List<TransferDocument> TransferDocuments { get; }
    /// <summary>
    /// Дата приёмки
    /// </summary>
    public DateOnly AcceptanceDate { get; }
    /// <summary>
    /// Дата проводки
    /// </summary>
    public DateOnly PostDate { get; }
    /// <summary>
    /// Дата поступления на склад
    /// </summary>
    public DateOnly StockArrivedDate { get; }
    /// <summary>
    /// Приходные ордеры
    /// </summary>
    public List<ReceiptOrder> ReceiptOrders { get; }
    /// <summary>
    /// Есть 179 Требование-накладная?
    /// </summary>
    public bool HasDemandInvoice { get; }
    public bool IsLinkedWithSap { get; set; }
    /// <summary>
    /// Есть 129 Универсальный корректировочный документ?
    /// </summary>
    public bool HasCorrectionalDocument { get; }
    public bool IsProcessed { get; set; }

    public DocsSet(string itemId,
                   Company company,
                   string registrationNumber,
                   List<TransferDocument> transferDocuments,
                   DateOnly acceptanceDate,
                   DateOnly postDate,
                   DateOnly stockArrivedDate,
                   List<ReceiptOrder> receiptOrders,
                   bool hasDemandInvoice,
                   bool isLinkedWithSap,
                   bool hasCorrectionalDocument)
    {
        ItemId = itemId;
        Company = company;
        RegistrationNumber = registrationNumber;
        Uri = new Uri($"https://asuedo.polyus.com/_layouts/wss/wssc.v4.dms.plz/pages/OpenWSSDocument.aspx?wssid=2038-{itemId}");
        TransferDocuments = transferDocuments;
        AcceptanceDate = acceptanceDate;
        PostDate = postDate;
        StockArrivedDate = stockArrivedDate;
        ReceiptOrders = receiptOrders;
        HasDemandInvoice = hasDemandInvoice;
        IsLinkedWithSap = isLinkedWithSap;
        HasCorrectionalDocument = hasCorrectionalDocument;
    }


    public ValidationResult Validate()
    {
        if (TransferDocuments.Count != 1)
        {
            return new ValidationResult("Передаточный документ не найден или найдено более 1 передаточного документа");
        }

        foreach (var transferDocument in TransferDocuments)
        {
            ValidationResult tdValidationResult = transferDocument.Validate();

            if (!tdValidationResult.IsValid)
            {
                return tdValidationResult;
            }
        }

        if (doNotProcessDocsSetsCompanySapCodeByContractorSapCode
                .GetValueOrDefault(TransferDocuments[0].Contractor.SapCode, string.Empty)
                .Equals(Company.SapCode))
        {
            return new ValidationResult("Комплекты данного контрагента по данной БЕ не обрабатываются");
        }

        if (AcceptanceDate == DateOnly.MinValue)
        {
            return new ValidationResult("Не удалось определить дату приёмки");
        }

        if (PostDate == DateOnly.MinValue)
        {
            return new ValidationResult("Не удалось определить дату проводки");
        }

        if (StockArrivedDate == DateOnly.MinValue)
        {
            return new ValidationResult("Не удалось определить дату поступления на склад");
        }

        if (ReceiptOrders.Any(x => excludedOperationTypesCodes.Contains(x.OperationTypeCode)))
        {
            return new ValidationResult(
                $"Найден приходный ордер с кодом вида операции из списка ({string.Join(", ", excludedOperationTypesCodes)})");
        }

        if (ReceiptOrders.Any(x => x.OperationTypeCode is null || x.PurschaseOrderNumber is null))
        {
            return new ValidationResult("Не удалось распознать информацию как минимум из одного 25 Приходный ордер");
        }

        if (ReceiptOrders.Any() && HasDemandInvoice)
        {
            return new ValidationResult("В комплекте одновременно и 25 Приходный(-ые) ордер(ы), и 179 Требование-накладная");
        }

        if (IsLinkedWithSap)
        {
            return new ValidationResult("Комплект уже связан с SAP");
        }

        if (HasCorrectionalDocument)
        {
            return new ValidationResult("В комплекте найден 129 Универсальный корректировочный документ");
        }

        return ValidationResult.Correct;
    }

    internal static readonly List<string> excludedOperationTypesCodes = new() { "107", "109" };
    /// <summary>
    /// ИСКЛЮЧЕНИЯ.<br/>
    /// Не обрабатывать комплекты, в которых пара (Код контрагента в SAP, Код БЕ в SAP) присутствует в данном словаре.
    /// </summary>
    internal static readonly Dictionary<string, string> doNotProcessDocsSetsCompanySapCodeByContractorSapCode =
        new()
        {
            { "1000003297", "1300" }, // ИСКИТИМИЗВЕСТЬ - Алдан
            { "1000003304", "1300" }  // ИМПЭКС ИНДАСТРИ - Алдан
        };
}
