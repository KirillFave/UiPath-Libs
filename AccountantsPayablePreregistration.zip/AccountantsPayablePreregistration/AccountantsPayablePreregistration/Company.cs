﻿using System.Net.Mail;

namespace AccountantsPayablePreregistration;

public class Company
{
    public Company(string name, string asuedoCode, string sapCode)
    {
        Name = name;
        AsuedoCode = asuedoCode;
        SapCode = sapCode;
    }

    public string Name { get; }
    public string AsuedoCode { get; }
    public string SapCode { get; }
    public MailAddress? Contact { get; set; }
    public string? ContactAsuedoId { get; set; }
}
