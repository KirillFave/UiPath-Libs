﻿namespace AccountantsPayablePreregistration;

public class Contractor
{
    public string SapCode { get; set; }
    public string Name { get; set; }
    public bool IsGasoline { get; set; }
    public bool IsExceptional { get; set; }

    public Contractor(string sapCode, string name)
    {
        SapCode = sapCode;
        Name = name;
    }

    public void SetGasolineFlag(List<string> gasolineContractorsSapCodes)
    {
        IsGasoline = gasolineContractorsSapCodes.Any(x => x.Equals(SapCode));
    }

    public void SetExceptionalFlag(List<string> exceptionalContractorsSapCodes)
    {
        IsExceptional = exceptionalContractorsSapCodes.Any(x => x.Equals(SapCode));
    }
}