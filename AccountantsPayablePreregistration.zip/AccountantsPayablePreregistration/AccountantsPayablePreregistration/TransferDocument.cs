﻿namespace AccountantsPayablePreregistration;

/// <summary>
/// Передаточный документ
/// </summary>
/// <remarks>
/// 04 Товарная накладная / 55 Универсальный передаточный документ / 248 исправительный передаточный документ
/// </remarks>
public class TransferDocument
{
    public string RegistrationNumber { get; }
    public string Number { get; }
    /// <summary>
    /// Дата документа
    /// </summary>
    public DateOnly Date { get; }
    public Contractor Contractor { get; }

    /// <summary>
    /// Суммарная стоимость всех товаров в документе БЕЗ учёта налога
    /// </summary>
    public double PriceExcludingTax { get; }
    /// <summary>
    /// Сумма налога
    /// </summary>
    public double Tax { get; }
    /// <summary>
    /// Суммарная стоимость всех товаров в документе с учётом налога
    /// </summary>
    public double PriceIncludingTax { get; }

    public TransferDocument(string registrationNumber,
                            string number,
                            DateOnly date,
                            Contractor contractor,
                            double priceExcludingTax,
                            double tax,
                            double priceIncludingTax)
    {
        RegistrationNumber = registrationNumber;
        Number = number;
        Date = date;
        Contractor = contractor;
        PriceExcludingTax = priceExcludingTax;
        Tax = tax;
        PriceIncludingTax = priceIncludingTax;
    }

    internal bool IsPriceAndTaxCorrect()
    {
        return Math.Abs(PriceExcludingTax + Tax - PriceIncludingTax) < 0.5;
    }

    internal readonly string messageBase = "Исключение в передаточном документе: ";
    internal readonly int numberMaxLength = 16;
    internal readonly int contractorSapCodeTargetLength = 10;

    public ValidationResult Validate()
    {
        if (string.IsNullOrWhiteSpace(Number) || Number.Length > numberMaxLength)
        {
            return new ValidationResult(
                messageBase + $"Номер не заполнен или номер длиннее {numberMaxLength} символов");
        }

        if (Date == DateOnly.MinValue)
        {
            return new ValidationResult(
                messageBase + "Не удалось определить дату");
        }

        if (string.IsNullOrWhiteSpace(Contractor.SapCode) || Contractor.SapCode.Length != contractorSapCodeTargetLength)
        {
            return new ValidationResult(
                messageBase + "Не удалось определить код SAP контрагента");
        }

        if (Contractor.IsGasoline)
        {
            return new ValidationResult(
                messageBase + "Контрагент, работающий с бензином");
        }

        if (!IsPriceAndTaxCorrect())
        {
            return new ValidationResult(
                messageBase + "Стоимость без учёта налога + налог НЕ РАВНЯЕТСЯ стоимости с учётом налога");
        }

        return ValidationResult.Correct;
    }
}
