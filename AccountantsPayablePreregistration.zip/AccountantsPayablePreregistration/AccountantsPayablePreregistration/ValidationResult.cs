﻿namespace AccountantsPayablePreregistration;

public class ValidationResult
{
    public static ValidationResult Correct => new(null);

    public ValidationResult(string? errorText)
    {
        IsValid = errorText is null;
        ErrorText = errorText;
    }

    public bool IsValid { get; }
    public string? ErrorText { get; }
}
