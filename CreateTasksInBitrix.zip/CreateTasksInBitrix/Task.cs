﻿using CustomProcess;

using System;
using System.IO;
using System.Net.Mail;

namespace CreateTasksInBitrix
{
    public class Task
    {
        public string Assignment { get; set; }
        public MailAddress[] Responsibles { get; set; }
        public MailAddress[] Coexecutors { get; set; }
        public MailAddress[] Observers { get; set; }
        public bool IsRegular { get; set; }
        public bool IsMasterTask { get; set; }
        public DateTime Deadline { get; set; }
        public DateTime StartDate { get; set; }
        public FileInfo[] Attachments;
        public bool IsCreatedInBitrix { get; set; }
        public Uri BitrixLink { get; set; }
        public Uri ParentObjectLink { get; set; }

        public Task(
            string assignment,
            MailAddress[] responsibles,
            MailAddress[] coexecutors,
            MailAddress[] observers,
            bool isRegular,
            bool isMasterTask,
            DateTime deadline,
            DateTime startDate,
            FileInfo[] attachments,
            Uri parentObjectLink)
        {
            if (assignment.IsNullOrWhiteSpace())
            {
                throw new ArgumentException($"'{nameof(assignment)}' cannot be null or whitespace.", nameof(assignment));
            }

            if (responsibles.IsNullOrEmpty())
            {
                throw new ArgumentException($"'{nameof(responsibles)}' cannot be null or empty.", nameof(responsibles));
            }

            Assignment = assignment;

            Responsibles = responsibles;
            Coexecutors = coexecutors;
            Observers = observers;

            IsRegular = isRegular;
            IsMasterTask = isMasterTask;

            Deadline = deadline;
            StartDate = startDate;

            Attachments = attachments;
            ParentObjectLink = parentObjectLink;
        }
    }
}
