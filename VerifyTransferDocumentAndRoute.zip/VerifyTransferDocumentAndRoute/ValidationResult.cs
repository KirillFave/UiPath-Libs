﻿namespace VerifyTransferDocumentAndRoute;

public class ValidationResult
{
    public readonly bool IsCorrect;
    public readonly string? ExceptionDescription;
    public static ValidationResult Correct => new();

    internal ValidationResult()
    {
        IsCorrect = true;
    }

    internal ValidationResult(string exceptionDescription)
    {
        IsCorrect = false;
        ExceptionDescription = exceptionDescription;
    }
}
