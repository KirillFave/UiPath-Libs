﻿namespace VerifyTransferDocumentAndRoute;

public class DocsSet
{
    public readonly string ListId;
    public readonly string ItemId;
    public readonly Uri Uri;
    public readonly string RegistrationNumber;
    public readonly Company Company;
    public readonly bool HasConnectedWithSap;
    public readonly bool HasPreregistrateResponsibleAssigned;
    public readonly bool HasAccountantAssigned;
    public readonly TransferDocument TransferDocument;

    public DocsSet(string listId,
                   string itemId,
                   string registrationNumber,
                   Company company,
                   bool hasConnectedWithSap,
                   bool hasPreregistrateResponsibleAssigned,
                   bool hasAccountantAssigned,
                   TransferDocument transferDocument)
    {
        ListId = listId;
        ItemId = itemId;
        Uri = new Uri($"https://asuedo.polyus.com/_layouts/wss/wssc.v4.dms.plz/pages/OpenWSSDocument.aspx?wssid={listId}-{itemId}");
        RegistrationNumber = registrationNumber;
        Company = company;
        HasConnectedWithSap = hasConnectedWithSap;
        HasPreregistrateResponsibleAssigned = hasPreregistrateResponsibleAssigned;
        HasAccountantAssigned = hasAccountantAssigned;
        TransferDocument = transferDocument;
    }

    public ValidationResult Validate()
    {
        if (HasConnectedWithSap)
        {
            return new ValidationResult("Комплект уже связан с SAP (повторная маршрутизация)");
        }

        if (HasPreregistrateResponsibleAssigned)
        {
            return new ValidationResult("В комплекте заполнено поле Ответственный за предварительную регистрацию (повторная маршрутизация)");
        }

        if (HasAccountantAssigned)
        {
            return new ValidationResult("В комплекте заполнено поле Ответственный бухгалтер (повторная маршрутизация)");
        }

        if (TransferDocument is null)
        {
            return new ValidationResult("Не найден передаточный документ");
        }

        return TransferDocument.Validate();
    }
}
