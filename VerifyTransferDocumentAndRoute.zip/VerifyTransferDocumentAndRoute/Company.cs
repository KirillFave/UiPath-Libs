﻿namespace VerifyTransferDocumentAndRoute;

public class Company
{
    public readonly string AsuedoCode;
    public readonly string SapCode;
    public readonly string Name;
    public readonly Client Client;

    public Company(string asuedoCode, string sapCode, string name, Client client)
    {
        AsuedoCode = asuedoCode ?? throw new ArgumentNullException(nameof(asuedoCode));
        SapCode = sapCode ?? throw new ArgumentNullException(nameof(sapCode));
        Name = name ?? throw new ArgumentNullException(nameof(name));
        Client = client ?? throw new ArgumentNullException(nameof(client));
    }
}
