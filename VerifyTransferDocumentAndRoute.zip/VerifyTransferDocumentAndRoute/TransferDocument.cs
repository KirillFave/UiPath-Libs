﻿namespace VerifyTransferDocumentAndRoute;

public class TransferDocument
{
    public readonly string ItemId;
    public readonly string ListId;
    public readonly Uri Uri;
    public readonly string Number;
    public readonly DateOnly Date;
    public readonly int? Status;
    public readonly TransactionParticipant Seller;
    public readonly TransactionParticipant Buyer;
    public readonly string LoadRecipientName;
    public readonly string LoadRecipientAddress;
    public readonly ShipmentDocument ShipmentDocument;
    public readonly string CurrencyCode;
    public readonly List<string> ProductsNames;
    public readonly bool HasTax;

    public TransferDocument(string itemId,
                            string listId,
                            string number,
                            DateOnly date,
                            int? status,
                            TransactionParticipant seller,
                            TransactionParticipant buyer,
                            string loadRecipientName,
                            string loadRecipientAddress,
                            ShipmentDocument shipmentDocument,
                            string currencyCode,
                            List<string> productsNames,
                            bool hasTax)
    {
        ItemId = itemId;
        ListId = listId;
        Uri = new Uri($"https://asuedo.polyus.com/_layouts/wss/wssc.v4.dms.plz/pages/OpenWSSDocument.aspx?wssid={listId}-{itemId}");
        Number = number;
        Date = date;
        Status = status;
        Seller = seller;
        Buyer = buyer;
        LoadRecipientName = loadRecipientName;
        LoadRecipientAddress = loadRecipientAddress;
        ShipmentDocument = shipmentDocument;
        CurrencyCode = currencyCode;
        ProductsNames = productsNames;
        HasTax = hasTax;
    }

    private const string RUBLE_CURRENCY_CODE = "643";
    private const int MIN_RUSSIAN_LETTERS_COUNT = 4;

    public ValidationResult Validate()
    {
        if (Status is null)
        {
            return new ValidationResult("Не удалось определить статус УПД");
        }
        if (HasTax && Status != 1)
        {
            return new ValidationResult("При наличии НДС должен быть статус УПД 1");
        }
        if (!HasTax && Status != 2)
        {
            return new ValidationResult("При отсутствии НДС должен быть статус УПД 2");
        }

        if (string.IsNullOrWhiteSpace(Number))
        {
            return new ValidationResult("Не заполнен номер УПД");
        }
        if (Date == DateOnly.MinValue)
        {
            return new ValidationResult("Не удалось определить дату передаточного документа");
        }

        if (Seller is null)
        {
            return new ValidationResult("Не найден продавец");
        }
        ValidationResult sellerValidationResult = Seller.Validate();
        if (!sellerValidationResult.IsCorrect)
        {
            return new ValidationResult("Продавец: " + sellerValidationResult.ExceptionDescription);
        }

        if (Buyer is null)
        {
            return new ValidationResult("Не найден покупатель");
        }
        ValidationResult buyerValidationResult = Buyer.Validate(true);
        if (!buyerValidationResult.IsCorrect)
        {
            return new ValidationResult("Покупатель: " + buyerValidationResult.ExceptionDescription);
        }

        if (string.IsNullOrWhiteSpace(LoadRecipientName))
        {
            return new ValidationResult("Не удалось определить наименование грузополучателя.");
        }
        if (string.IsNullOrWhiteSpace(LoadRecipientAddress))
        {
            return new ValidationResult("Не удалось определить адрес грузополучателя.");
        }

        if (ShipmentDocument is null)
        {
            return new ValidationResult("Не найден документ об отгрузке");
        }
        ValidationResult shipmentDocumentValidationResult = ShipmentDocument.Validate();
        if (!shipmentDocumentValidationResult.IsCorrect)
        {
            return new ValidationResult("Документ об отгрузке: " + shipmentDocumentValidationResult.ExceptionDescription);
        }

        if (Number != ShipmentDocument.Number)
        {
            return new ValidationResult("Номер передаточного документа НЕ равен номеру документа об отгрузке.");
        }
        if (Date != ShipmentDocument.Date)
        {
            return new ValidationResult("Дата передаточного документа НЕ равна дате документа об отгрузке.");
        }

        if (string.IsNullOrWhiteSpace(CurrencyCode))
        {
            return new ValidationResult("Не заполнена валюта");
        }
        if (!CurrencyCode.Equals(RUBLE_CURRENCY_CODE))
        {
            return new ValidationResult($"Код валюты <> {RUBLE_CURRENCY_CODE} (РУБ)");
        }

        if (ProductsNames is null || ProductsNames.Count == 0)
        {
            return new ValidationResult("Не распознаны имена товаров.");
        }
        foreach (string productName in ProductsNames)
        {
            if (string.IsNullOrWhiteSpace(productName))
            {
                return new ValidationResult("Не удалось распознать наименование товара");
            }

            string lower = productName.ToLower();
            int russianLettersCount = lower.Count(x => 'а' <= x && x <= 'я');

            if (russianLettersCount < MIN_RUSSIAN_LETTERS_COUNT)
            {
                return new ValidationResult($"Наименование товара из менее содержит менее {MIN_RUSSIAN_LETTERS_COUNT} русских букв");
            }
        }

        return ValidationResult.Correct;
    }
}
