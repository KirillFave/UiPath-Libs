﻿namespace VerifyTransferDocumentAndRoute;

public class Client
{
    public readonly string EmailAddress;
    public readonly string FullName;
    public readonly string AsuedoId;

    public Client(string emailAddress, string fullName, string asuedoId)
    {
        EmailAddress = emailAddress ?? throw new ArgumentNullException(nameof(emailAddress));
        FullName = fullName ?? throw new ArgumentNullException(nameof(fullName));
        AsuedoId = asuedoId ?? throw new ArgumentNullException(nameof(asuedoId));
    }
}