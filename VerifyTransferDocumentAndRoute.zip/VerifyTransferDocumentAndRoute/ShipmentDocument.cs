﻿namespace VerifyTransferDocumentAndRoute;

public class ShipmentDocument
{
    public readonly string Number;
    public readonly DateOnly Date;

    public ShipmentDocument(string number, DateOnly date)
    {
        Number = number;
        Date = date;
    }

    public ValidationResult Validate()
    {
        if (string.IsNullOrWhiteSpace(Number))
        {
            return new ValidationResult("Не заполнен номер");
        }

        if (Date == DateOnly.MinValue)
        {
            return new ValidationResult("Не заполнена дата");
        }

        return ValidationResult.Correct;
    }
}