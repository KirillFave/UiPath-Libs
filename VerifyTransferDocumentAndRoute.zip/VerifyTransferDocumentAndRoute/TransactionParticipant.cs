﻿namespace VerifyTransferDocumentAndRoute;

public class TransactionParticipant
{
    public readonly string Name;
    public readonly string Address;
    public readonly string INN;
    public readonly string KPP;

    public TransactionParticipant(string name, string address, string inn, string kpp)
    {
        Name = name;
        Address = address;
        INN = inn;
        KPP = kpp;
    }

    private readonly List<string> _polyusCompaniesNames = new()
    {
        "ао \"полюс алдан\"",
        "ао \"полюс вернинское\"",
        "ао \"полюс красноярск\"",
        "ао \"полюс логистика\"",
        "ао \"полюс магадан\"",
        "ао \"развитие\"",
        "ооо \"ук полюс\""
    };

    public ValidationResult Validate(bool isOnlyPolyusCompanies = false)
    {
        if (string.IsNullOrEmpty(Name))
        {
            return new ValidationResult("Не заполнено ИМЯ");
        }

        if (isOnlyPolyusCompanies)
        {
            if (!_polyusCompaniesNames.Contains(Name.ToLower()))
            {
                return new ValidationResult("Не занесён в список БЕ ГК Полюс");
            }
        }

        if (string.IsNullOrEmpty(Address))
        {
            return new ValidationResult("Не заполнен адрес");
        }

        if (string.IsNullOrEmpty(INN))
        {
            return new ValidationResult("Не заполнен ИНН");
        }

        if (string.IsNullOrEmpty(KPP))
        {
            return new ValidationResult("Не заполнен КПП");
        }

        return ValidationResult.Correct;
    }
}