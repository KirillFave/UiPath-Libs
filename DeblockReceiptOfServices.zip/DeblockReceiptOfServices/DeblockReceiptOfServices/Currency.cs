﻿namespace DeblockReceiptOfServices
{
    public class Currency
    {
        public string Name;
        public int Code;

        public Currency(string name, int code)
        {
            Name = name;
            Code = code;
        }
    }
}