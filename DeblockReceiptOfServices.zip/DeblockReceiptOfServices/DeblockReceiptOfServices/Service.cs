﻿namespace DeblockReceiptOfServices
{
    public class Service
    {
        public string Name;
        public string TaxRate;

        public Service(string name, string taxRate)
        {
            Name = name;
            TaxRate = taxRate;
        }
    }
}