﻿namespace DeblockReceiptOfServices
{
    public class Company
    {
        public string AsuedoCode;
        public string SapCode;
        public string Name;

        public Company(string asuedoCode, string sapCode, string name)
        {
            if (string.IsNullOrWhiteSpace(asuedoCode))
            {
                throw new ArgumentException($"'{nameof(asuedoCode)}' cannot be null or whitespace.", nameof(asuedoCode));
            }

            if (string.IsNullOrWhiteSpace(sapCode))
            {
                throw new ArgumentException($"'{nameof(sapCode)}' cannot be null or whitespace.", nameof(sapCode));
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException($"'{nameof(name)}' cannot be null or whitespace.", nameof(name));
            }

            AsuedoCode = asuedoCode;
            SapCode = sapCode;
            Name = name;
        }
    }
}