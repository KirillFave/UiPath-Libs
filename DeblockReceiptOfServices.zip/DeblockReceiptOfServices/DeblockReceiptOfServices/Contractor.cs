﻿namespace DeblockReceiptOfServices
{
    public class Contractor
    {
        public string SapCode;
        public string Name;

        public Contractor(string sapCode, string name)
        {
            SapCode = sapCode;
            Name = name;
        }   
    }
}