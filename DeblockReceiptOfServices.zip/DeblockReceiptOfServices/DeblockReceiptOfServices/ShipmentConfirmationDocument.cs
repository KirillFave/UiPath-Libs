﻿namespace DeblockReceiptOfServices
{
    public class ShipmentConfirmationDocument
    {
        public string Name;
        public string Number;
        public DateOnly Date;

        public ShipmentConfirmationDocument(string name, string number, DateOnly date)
        {
            Name = name;
            Number = number;
            Date = date;
        }
    }
}