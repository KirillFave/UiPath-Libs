﻿namespace DeblockReceiptOfServices
{
    public class TransactionParticipant
    {
        public string Name;
        public string Address;
        public string INN;
        public string KPP;

        public TransactionParticipant(string name, string address, string inn, string kpp)
        {
            Name = name;
            Address = address;
            INN = inn;
            KPP = kpp;
        }
    }
}