﻿namespace DeblockReceiptOfServices
{
    public class DocsSet
    {
        public string ListId;
        public string ItemId;
        public Uri Link;
        public string RegistrationNumber;
        public bool IsConnectedWithSap;

        public Company Company;
        public Contractor Contractor;

        public UniversalTransferDocument UTD;

        public string? WrongInputDataMessage;

        public DocsSet(string listId,
                       string itemId,
                       string registrationNumber,
                       bool isConnectedWithSap,
                       Company company,
                       Contractor contractor,
                       UniversalTransferDocument utd)
        {
            if (string.IsNullOrEmpty(listId))
            {
                throw new ArgumentException($"'{nameof(listId)}' cannot be null or empty.", nameof(listId));
            }

            if (string.IsNullOrEmpty(itemId))
            {
                throw new ArgumentException($"'{nameof(itemId)}' cannot be null or empty.", nameof(itemId));
            }

            if (string.IsNullOrEmpty(registrationNumber))
            {
                throw new ArgumentException($"'{nameof(registrationNumber)}' cannot be null or empty.", nameof(registrationNumber));
            }

            ListId = listId;
            ItemId = itemId;
            Link = new Uri($"https://asuedo.polyus.com/_layouts/wss/wssc.v4.dms.plz/pages/OpenWSSDocument.aspx?wssid={listId}-{itemId}");
            RegistrationNumber = registrationNumber;
            IsConnectedWithSap = isConnectedWithSap;
            Company = company;
            Contractor = contractor;
            UTD = utd;
        }
    }
}