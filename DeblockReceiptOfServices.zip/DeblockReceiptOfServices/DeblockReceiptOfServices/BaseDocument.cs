﻿namespace DeblockReceiptOfServices
{
    public class BaseDocument
    {
        public string Name;
        public string Number;
        public DateOnly Date;

        public BaseDocument(string name, string number, DateOnly date)
        {
            Name = name;
            Number = number;
            Date = date;
        }
    }
}