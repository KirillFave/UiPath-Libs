﻿namespace DeblockReceiptOfServices
{
    public class PaymentDocument
    {
        public string Number;
        public DateOnly Date;

        public PaymentDocument(string number, DateOnly date)
        {
            Number = number;
            Date = date;
        }
    }
}