﻿namespace DeblockReceiptOfServices
{
    public class UniversalTransferDocument
    {
        public string ListId;
        public string ItemId;
        public Uri Link;
        public string RegistrationNumber;
        public string Number;

        public DateOnly Date;

        public bool IsRevisionActual;
        public int? Status;

        public List<Service> Services;
        public string TaxCode;

        public Currency Currency;
        public float Cost;
        public float Tax;
        public float Sum;

        public TransactionParticipant Seller;
        public TransactionParticipant Buyer;

        public BaseDocument BaseDocument;

        public ShipmentConfirmationDocument ShipmentConfirmationDocument;
        public DateOnly ReceiveDate;

        public bool HasSenderDigitalSignature;
        public bool HasReceiverDigitalSignature;

        public List<PaymentDocument> PaymentDocuments;

        public UniversalTransferDocument(string listId,
                                         string itemId,
                                         string registrationNumber,
                                         string number,
                                         DateOnly date,
                                         bool isRevisionActual,
                                         int? status,
                                         List<Service> services,
                                         string taxCode,
                                         Currency currency,
                                         float cost,
                                         float tax,
                                         float sum,
                                         TransactionParticipant seller,
                                         TransactionParticipant buyer,
                                         BaseDocument baseDocument,
                                         ShipmentConfirmationDocument shipmentConfirmationDocument,
                                         DateOnly receiveDate,
                                         bool hasSenderDigitalSignature,
                                         bool hasReceiverDigitalSignature,
                                         List<PaymentDocument> paymentDocuments)
        {
            if (string.IsNullOrEmpty(listId))
            {
                throw new ArgumentException($"'{nameof(listId)}' cannot be null or empty.", nameof(listId));
            }

            if (string.IsNullOrEmpty(itemId))
            {
                throw new ArgumentException($"'{nameof(itemId)}' cannot be null or empty.", nameof(itemId));
            }

            ListId = listId;
            ItemId = itemId;
            Link = new Uri($"https://asuedo.polyus.com/_layouts/wss/wssc.v4.dms.plz/pages/OpenWSSDocument.aspx?wssid={listId}-{itemId}");
            RegistrationNumber = registrationNumber;
            Number = number;
            Date = date;
            IsRevisionActual = isRevisionActual;
            Status = status;
            Currency = currency;
            Cost = cost;
            Tax = tax;
            Sum = sum;
            Seller = seller;
            Buyer = buyer;
            BaseDocument = baseDocument;
            Services = services;
            TaxCode = taxCode;
            ShipmentConfirmationDocument = shipmentConfirmationDocument;
            ReceiveDate = receiveDate;
            HasSenderDigitalSignature = hasSenderDigitalSignature;
            HasReceiverDigitalSignature = hasReceiverDigitalSignature;
            PaymentDocuments = paymentDocuments;
        }
    }
}